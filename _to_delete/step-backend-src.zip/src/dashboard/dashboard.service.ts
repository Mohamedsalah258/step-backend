import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { Student } from '../database/entities/student.entity'
import {
  Subscription,
  SubscriptionStatus,
} from '../database/entities/subscription.entity'
import { ActivityLog } from '../database/entities/activity-log.entity'
import {
  ActionType,
  ACTION_DASHBOARD_LABEL,
  ACTION_DASHBOARD_STATUS,
} from '../common/action-catalog'
import { lastSixMonths } from '../common/arabic-months'

@Injectable()
export class DashboardService {
  constructor(
    @InjectRepository(Student) private studentsRepo: Repository<Student>,
    @InjectRepository(Subscription)
    private subscriptionsRepo: Repository<Subscription>,
    @InjectRepository(ActivityLog)
    private activityRepo: Repository<ActivityLog>,
  ) {}

  /**
   * ⚠️ activeCourses / pendingOrders / pendingDeviceResets قيم تقريبية/صفرية
   * لحد ما دومين Courses و Orders يتبنوا بنفس الطريقة (شوف README قسم "ديون
   * تقنية"). باقي الأرقام حقيقية 100% من الداتابيز.
   */
  async stats() {
    const [totalStudents, activeSubscriptions, revenueRow, activeCoursesRow] =
      await Promise.all([
        this.studentsRepo.count(),
        this.subscriptionsRepo.count({
          where: { status: SubscriptionStatus.ACTIVE },
        }),
        this.subscriptionsRepo
          .createQueryBuilder('s')
          .select('COALESCE(SUM(s.price), 0)', 'total')
          .where('s.status = :status', { status: SubscriptionStatus.ACTIVE })
          .getRawOne<{ total: string }>(),
        this.subscriptionsRepo
          .createQueryBuilder('s')
          .select('COUNT(DISTINCT s.courseName)', 'total')
          .where('s.status = :status', { status: SubscriptionStatus.ACTIVE })
          .getRawOne<{ total: string }>(),
      ])

    return {
      totalStudents,
      activeSubscriptions,
      courseRevenue: Number(revenueRow?.total ?? 0),
      activeCourses: Number(activeCoursesRow?.total ?? 0),
      // TODO: يتحدث لما دومين Orders يتبني — حاليًا مفيش جدول Orders
      pendingOrders: 0,
      // TODO: مفيش مفهوم "طلب ريست معلّق" في هذا الإصدار — الريست إجراء فوري
      pendingDeviceResets: 0,
    }
  }

  /** بروكسي لمعدل طلبات الشراء من تاريخ إنشاء الاشتراكات (لحد ما دومين Orders يتبني) */
  async ordersTrend() {
    const months = lastSixMonths()
    const counts = await this.countsPerMonth(months, 'subscribedAt')
    // الديزاين الأصلي بيعرض الترتيب من الأحدث للأقدم (يونيو → يناير)
    const ordered = [...months].reverse()
    return {
      labels: ordered.map((m) => m.label),
      points: ordered.map((m) => counts.get(`${m.year}-${m.month}`) ?? 0),
    }
  }

  async subsPerCourse() {
    const rows = await this.subscriptionsRepo
      .createQueryBuilder('s')
      .select('s.courseName', 'label')
      .addSelect('COUNT(*)', 'value')
      .groupBy('s.courseName')
      .orderBy('value', 'DESC')
      .limit(5)
      .getRawMany<{ label: string; value: string }>()
    return rows.map((r) => ({ label: r.label, value: Number(r.value) }))
  }

  async monthlyRevenue() {
    const months = lastSixMonths()
    const rows = await this.subscriptionsRepo
      .createQueryBuilder('s')
      .select("date_trunc('month', s.subscribedAt)", 'bucket')
      .addSelect('COALESCE(SUM(s.price), 0)', 'total')
      .where('s.status = :status', { status: SubscriptionStatus.ACTIVE })
      .groupBy('bucket')
      .getRawMany<{ bucket: Date; total: string }>()

    const byKey = new Map(
      rows.map((r) => [
        `${new Date(r.bucket).getFullYear()}-${new Date(r.bucket).getMonth()}`,
        Number(r.total),
      ]),
    )
    return months.map((m) => ({
      label: m.label,
      value: byKey.get(`${m.year}-${m.month}`) ?? 0,
    }))
  }

  async recentActivity(limit = 5) {
    const rows = await this.activityRepo.find({
      order: { createdAt: 'DESC' },
      take: limit,
    })
    return rows.map((r) => {
      const action = r.actionType as ActionType
      return {
        id: r.id,
        activity: ACTION_DASHBOARD_LABEL[action] ?? r.actionType,
        student: r.studentNameSnapshot ?? 'النظام',
        content: r.courseNameSnapshot ?? r.details ?? '—',
        date: r.createdAt.toISOString(),
        status: ACTION_DASHBOARD_STATUS[action] ?? 'قيد المراجعة',
      }
    })
  }

  private async countsPerMonth(
    months: { year: number; month: number }[],
    dateColumn: 'subscribedAt',
  ) {
    const rows = await this.subscriptionsRepo
      .createQueryBuilder('s')
      .select(`date_trunc('month', s.${dateColumn})`, 'bucket')
      .addSelect('COUNT(*)', 'total')
      .groupBy('bucket')
      .getRawMany<{ bucket: Date; total: string }>()

    const map = new Map<string, number>()
    for (const r of rows) {
      const d = new Date(r.bucket)
      map.set(`${d.getFullYear()}-${d.getMonth()}`, Number(r.total))
    }
    return map
  }
}

import { Module } from '@nestjs/common'
import { ConfigModule } from '@nestjs/config'
import { TypeOrmModule } from '@nestjs/typeorm'
import { Student } from './database/entities/student.entity'
import { ResetLog } from './database/entities/reset-log.entity'
import { Subscription } from './database/entities/subscription.entity'
import { ActivityLog } from './database/entities/activity-log.entity'
import { StudentsModule } from './students/students.module'
import { DashboardModule } from './dashboard/dashboard.module'
import { ActivityLogModule } from './activity-log/activity-log.module'

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRoot({
      type: 'postgres',
      url: process.env.DATABASE_URL,
      entities: [Student, ResetLog, Subscription, ActivityLog],
      // ⚠️ synchronize:true مريح في التطوير بس (بيبني الجداول من الـ entities
      // تلقائي من غير migrations). لازم يتقفل ويتستبدل بـ migrations حقيقية
      // (typeorm migration:generate) قبل أي نشر production حقيقي.
      synchronize: true,
      logging: false,
    }),
    StudentsModule,
    DashboardModule,
    ActivityLogModule,
  ],
})
export class AppModule {}

import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Student } from './student.entity'

export enum SubscriptionStatus {
  ACTIVE = 'ACTIVE',
  CANCELLED = 'CANCELLED',
}

/** يقابل STUDENT_SUBSCRIPTIONS / SubscriptionRow */
@Entity('subscriptions')
export class Subscription {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => Student, (s) => s.subscriptions, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'studentId' })
  student: Student

  @Column()
  studentId: string

  @Column()
  courseName: string

  @Column()
  collegeName: string

  @Column({
    type: 'enum',
    enum: SubscriptionStatus,
    default: SubscriptionStatus.ACTIVE,
  })
  status: SubscriptionStatus

  /** جنيه مصري */
  @Column({ type: 'numeric', precision: 10, scale: 2 })
  price: string

  @CreateDateColumn({ type: 'timestamptz' })
  subscribedAt: Date
}

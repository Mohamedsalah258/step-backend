# STEP Backend — API الحقيقي بتاع لوحة تحكم STEP

باك اند **NestJS + TypeORM + PostgreSQL** بيغطي أول دومين حقيقي من داش بورد
STEP (`D:\Step`): **الطلاب والأجهزة** + **لوحة التحكم الرئيسية** + **سجل
العمليات**. باقي الدومينات (Orders, Academic, Courses, Payments, Reports,
Content) هتتضاف بنفس النمط لاحقًا.

## ليه TypeORM مش Prisma

اتفقنا الأول على Prisma، لكن بيئة التطوير السحابية اللي اتبنى فيها المشروع
أول مرة كانت بتمنع تحميل الـ engine binaries بتاعت Prisma (مشكلة شبكة في
بيئة العمل، مش في Prisma نفسه). TypeORM بيدّي نفس الحماية (type-safe
entities/repositories) من غير ما يحتاج يحمّل أي binary — بيشتغل بـ `pg`
(driver JS عادي) بس. لو حابب ترجع لـ Prisma على جهازك (فيه إنترنت كامل)
ده ممكن كـ تعديل لاحق، بس مش لازم.

## التشغيل

```bash
npm install

# 1) شغّل PostgreSQL محليًا وأنشئ قاعدة بيانات
createdb step_db   # أو أي طريقة تانية عندك

# 2) اعمل نسخة من .env.example وعدّل DATABASE_URL لو مختلف عندك
cp .env.example .env

# 3) اعمل seed (بيبني الجداول تلقائي أول مرة عن طريق synchronize:true)
npx ts-node -r tsconfig-paths/register src/database/seed.ts

# 4) شغّل السيرفر
npm run start:dev
```

- API: `http://localhost:3000`
- توثيق Swagger تفاعلي: `http://localhost:3000/api-docs`
- Swagger JSON (لتوليد types/client في الفرونت والموبايل): `http://localhost:3000/api-docs-json`

## القرارات المعمارية

### قرار #1 — `synchronize: true` بدل migrations دلوقتي

مريح جدًا في مرحلة النموذج الأولي: الجداول بتتبني تلقائي من الـ entities.
**قبل أي نشر production حقيقي**، لازم يتقفل ده ويتستبدل بـ TypeORM migrations
حقيقية (`typeorm migration:generate`) عشان تتحكم في تعديلات السكيما بأمان.

### قرار #2 — النصوص العربية الجاهزة للعرض تفضل في الفرونت

الـ API بيرجّع بس القيم الديناميكية الخام (status كـ enum متحول لنص عربي
عند الإخراج، أرقام خام للأسعار، تواريخ ISO). أي نص UI ثابت (عناوين
الأعمدة، labels الفورمات، الـ placeholders) مايتحطش هنا — هو أصلًا موجود
في `data/*.ts` بالفرونت وبيفضل زي ما هو.

استثناء واحد: حالات (`status`) الطالب/الاشتراك بترجع كنص عربي جاهز
(`نشط`/`محظور`/`ملغي`...) عشان بالظبط يطابق مفاتيح `STATUS_TONE` في
`components/ui/Badge.tsx` بالفرونت من غير أي تعديل هناك. الخريطة دي
لو احتجت تضيف حالة جديدة، حدّثها في `src/common/action-catalog.ts` هنا
**و** `STATUS_TONE` هناك مع بعض.

### قرار #3 — `ActionType` مركزي لكل الأحداث

كل حدث (ban/unban/device-reset/cancel-sub/open-course...) بيتسجل في جدول
`activity_logs` واحد، وبيغذي شاشتين مختلفتين في الفرونت (RECENT_ACTIVITY
بالداشبورد + ACTIVITY_LOG بصفحة سجل العمليات) من نفس المصدر — بعكس الموك
القديم اللي كان فيهم بيانات مختلفة/متضاربة في كل ملف. النص العربي والتون
لكل نوع حدث موجودين في `src/common/action-catalog.ts` بس — أي دومين جديد
(orders, courses...) يضيف مفاتيحه هناك.

### قرار #4 — حد الريست المبسّط (3 كل 30 يوم من آخر ريست)

مش rolling window شهري حقيقي (زي "يترجع صفر أول كل شهر ميلادي") — إنما
عداد بسيط يوصل لحد أقصى 3 من غير ريست تلقائي. لو محتاج المنطق الشهري
الحقيقي، ده تعديل صغير في `StudentsService.deviceReset`.

## ديون تقنية معروفة (زي WORKFLOW.md بالظبط بالفرونت)

1. **Orders / Courses domains لسه مش موجودين** — `dashboard/stats` بيرجّع
   `pendingOrders: 0` و`activeCourses` تقريبي (عدد الكورسات المميزة من
   الاشتراكات الفعلية بس، مش من جدول Courses حقيقي).
2. **`pendingDeviceResets` دايمًا 0** — الريست في النسخة دي إجراء فوري
   (زرار بيتنفذ على طول)، مفيش مفهوم "طلب ريست معلّق للموافقة" لسه.
3. **مفيش Auth/JWT** — كل الـ endpoints مفتوحة دلوقتي. لازم يتضاف قبل أي
   نشر حقيقي (قرار مقصود لتبسيط النموذج الأولي).
4. **الـ `index` في جدول الطلاب** رقم عرض حسب ترتيب الصفحة الحالية بس، مش
   عمود مخزّن — يتغيّر لو غيّرت الترتيب أو الفلتر.
5. **CSV export** بيرجّع كل الصفوف المفلترة دفعة واحدة (من غير حد أقصى) —
   لو عدد السجلات كبر جدًا، محتاج streaming بدل تجميعها في الميموري.

## خريطة الـ endpoints

| Method | Path | الوظيفة |
|---|---|---|
| GET | `/students` | قائمة + بحث `q` + تاب `tab` + فلتر كورس `course` + صفحات |
| GET | `/students/:id` | تفاصيل كاملة (بروفايل + جهاز + سجل ريست + اشتراكات) |
| POST | `/students/:id/ban` | حظر |
| POST | `/students/:id/unban` | فك حظر |
| POST | `/students/:id/device-reset` | ريست جهاز (حد أقصى 3) |
| POST | `/students/:id/subscriptions/:subId/cancel` | إلغاء اشتراك |
| POST | `/students/:id/subscriptions/open` | فتح كورس يدوي `{courseName, collegeName?, price?}` |
| GET | `/dashboard/stats` | كروت الـ KPI في أعلى الداشبورد |
| GET | `/dashboard/orders-trend` | آخر 6 شهور (بروكسي من الاشتراكات) |
| GET | `/dashboard/subs-per-course` | أكتر 5 كورسات اشتراكًا |
| GET | `/dashboard/monthly-revenue` | الإيراد الشهري (آخر 6 شهور) |
| GET | `/dashboard/recent-activity` | آخر 5 أحداث |
| GET | `/activity-log` | سجل العمليات + بحث/فلتر/صفحات حقيقية |
| GET | `/activity-log/stats` | عدادات أسبوعي/اليوم/إجمالي |
| GET | `/activity-log/export.csv` | تصدير نفس النتائج المفلترة CSV |

## الخطوة الجاية

لما تحب تضيف دومين تاني (Orders مثلًا)، اتبع نفس النمط بالظبط: entity في
`src/database/entities/`، module/service/controller في مجلد باسم
الدومين، وأضف مفاتيح `ActionType` جديدة في `action-catalog.ts` لو فيه
أحداث جديدة. بعد ما تخلص، ارجع لملف `data/<domain>.ts` المقابل في ريبو
الداش بورد وبدّل الـ exports الديناميكية بنداءات لهذا الـ API — بالظبط
زي ما اتعمل في `students.ts` و`dashboard.ts`.

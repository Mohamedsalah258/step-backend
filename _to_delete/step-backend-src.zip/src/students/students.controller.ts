import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
} from '@nestjs/common'
import { ApiTags } from '@nestjs/swagger'
import { StudentsService } from './students.service'
import { ListStudentsQueryDto } from './dto/list-students-query.dto'
import { OpenCourseDto } from './dto/open-course.dto'

@ApiTags('students')
@Controller('students')
export class StudentsController {
  constructor(private readonly studentsService: StudentsService) {}

  @Get()
  list(@Query() query: ListStudentsQueryDto) {
    return this.studentsService.list(query)
  }

  @Get(':id')
  getDetail(@Param('id') id: string) {
    return this.studentsService.getDetail(id)
  }

  @Post(':id/ban')
  ban(@Param('id') id: string) {
    return this.studentsService.ban(id)
  }

  @Post(':id/unban')
  unban(@Param('id') id: string) {
    return this.studentsService.unban(id)
  }

  @Post(':id/device-reset')
  deviceReset(@Param('id') id: string) {
    return this.studentsService.deviceReset(id)
  }

  @Post(':id/subscriptions/:subId/cancel')
  cancelSubscription(
    @Param('id') id: string,
    @Param('subId') subId: string,
  ) {
    return this.studentsService.cancelSubscription(id, subId)
  }

  @Post(':id/subscriptions/open')
  openCourse(@Param('id') id: string, @Body() dto: OpenCourseDto) {
    return this.studentsService.openCourse(id, dto)
  }
}

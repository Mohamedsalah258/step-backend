import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Brackets, Repository } from 'typeorm'
import { Student, StudentStatus } from '../database/entities/student.entity'
import { ResetLog } from '../database/entities/reset-log.entity'
import {
  Subscription,
  SubscriptionStatus,
} from '../database/entities/subscription.entity'
import { ActivityLog } from '../database/entities/activity-log.entity'
import { ActionType } from '../common/action-catalog'
import { STUDENT_STATUS_AR, SUBSCRIPTION_STATUS_AR } from '../common/action-catalog'
import { ListStudentsQueryDto } from './dto/list-students-query.dto'
import { OpenCourseDto } from './dto/open-course.dto'

const MAX_RESETS_PER_CYCLE = 3
const RESET_CYCLE_DAYS = 30

@Injectable()
export class StudentsService {
  constructor(
    @InjectRepository(Student) private studentsRepo: Repository<Student>,
    @InjectRepository(ResetLog) private resetLogsRepo: Repository<ResetLog>,
    @InjectRepository(Subscription)
    private subscriptionsRepo: Repository<Subscription>,
    @InjectRepository(ActivityLog)
    private activityRepo: Repository<ActivityLog>,
  ) {}

  /** GET /students — بحث حقيقي (name/email) + فلتر تاب + فلتر كورس + صفحات */
  async list(query: ListStudentsQueryDto) {
    const page = query.page ?? 1
    const pageSize = query.pageSize ?? 8

    const qb = this.studentsRepo
      .createQueryBuilder('student')
      .leftJoin('student.subscriptions', 'sub')
      .distinct(true)

    if (query.q) {
      qb.andWhere(
        new Brackets((b) => {
          b.where('student.name ILIKE :q', { q: `%${query.q}%` }).orWhere(
            'student.email ILIKE :q',
            { q: `%${query.q}%` },
          )
        }),
      )
    }

    if (query.tab === 'active') {
      qb.andWhere('student.status = :status', { status: StudentStatus.ACTIVE })
    } else if (query.tab === 'banned') {
      qb.andWhere('student.status = :status', { status: StudentStatus.BANNED })
    }

    if (query.course) {
      qb.andWhere('sub.courseName ILIKE :course', { course: `%${query.course}%` })
    }

    const total = await qb.getCount()

    const rows = await qb
      .orderBy('student.registeredAt', 'ASC')
      .skip((page - 1) * pageSize)
      .take(pageSize)
      .getMany()

    // عدد الاشتراكات الفعلي لكل طالب (منفصل عن استعلام البحث عشان الـ join
    // بتاع فلتر الكورس ميأثرش على العدّ)
    const items = await Promise.all(
      rows.map(async (s, i) => {
        const subsCount = await this.subscriptionsRepo.count({
          where: { studentId: s.id },
        })
        return {
          id: s.id,
          /** رقم العرض داخل الصفحة الحالية بس — مش عمود مخزّن في الداتابيز */
          index: String((page - 1) * pageSize + i + 1),
          name: s.name,
          email: s.email,
          phone: s.phone,
          subscriptions: String(subsCount),
          device: s.deviceModel ?? '—',
          status: STUDENT_STATUS_AR[s.status],
        }
      }),
    )

    const [all, active, banned] = await Promise.all([
      this.studentsRepo.count(),
      this.studentsRepo.count({ where: { status: StudentStatus.ACTIVE } }),
      this.studentsRepo.count({ where: { status: StudentStatus.BANNED } }),
    ])

    return {
      items,
      total,
      page,
      pageSize,
      pages: Math.max(1, Math.ceil(total / pageSize)),
      tabs: { all, active, banned },
    }
  }

  async getDetail(id: string) {
    const student = await this.studentsRepo.findOne({ where: { id } })
    if (!student) throw new NotFoundException('الطالب غير موجود')

    const [subscriptions, resetLog] = await Promise.all([
      this.subscriptionsRepo.find({
        where: { studentId: id },
        order: { subscribedAt: 'ASC' },
      }),
      this.resetLogsRepo.find({
        where: { studentId: id },
        order: { createdAt: 'DESC' },
      }),
    ])

    const resetsPercent = Math.min(
      100,
      Math.round((student.resetsUsed / MAX_RESETS_PER_CYCLE) * 100),
    )
    const nextResetAt =
      student.resetsUsed >= MAX_RESETS_PER_CYCLE && student.lastResetAt
        ? new Date(
            student.lastResetAt.getTime() + RESET_CYCLE_DAYS * 24 * 60 * 60 * 1000,
          ).toISOString()
        : null

    return {
      id: student.id,
      name: student.name,
      email: student.email,
      phone: student.phone,
      status: STUDENT_STATUS_AR[student.status],
      registeredAt: student.registeredAt.toISOString(),
      device: student.deviceModel
        ? { model: student.deviceModel, identifier: student.deviceIdentifier }
        : null,
      resetsUsed: student.resetsUsed,
      maxResets: MAX_RESETS_PER_CYCLE,
      resetsPercent,
      lastResetAt: student.lastResetAt?.toISOString() ?? null,
      nextResetAt,
      resetLog: resetLog.map((r) => ({
        id: r.id,
        model: r.deviceModel,
        by: r.byAdmin,
        date: r.createdAt.toISOString(),
      })),
      subscriptions: subscriptions.map((s, i) => ({
        id: s.id,
        index: String(i + 1),
        course: s.courseName,
        college: s.collegeName,
        date: s.subscribedAt.toISOString(),
        status: SUBSCRIPTION_STATUS_AR[s.status],
        price: Number(s.price),
      })),
    }
  }

  async ban(id: string) {
    const student = await this.mustFind(id)
    student.status = StudentStatus.BANNED
    await this.studentsRepo.save(student)
    await this.logActivity(ActionType.BAN_STUDENT, student, {
      details: student.deviceModel ? `الجهاز ${student.deviceModel}` : undefined,
    })
    return { ok: true }
  }

  async unban(id: string) {
    const student = await this.mustFind(id)
    student.status = StudentStatus.ACTIVE
    await this.studentsRepo.save(student)
    await this.logActivity(ActionType.UNBAN_STUDENT, student, {})
    return { ok: true }
  }

  async deviceReset(id: string) {
    const student = await this.mustFind(id)
    if (student.resetsUsed >= MAX_RESETS_PER_CYCLE) {
      throw new BadRequestException(
        `الطالب استهلك أقصى عدد ريست مسموح (${MAX_RESETS_PER_CYCLE}) لهذه الدورة`,
      )
    }
    student.resetsUsed += 1
    student.lastResetAt = new Date()
    await this.studentsRepo.save(student)

    await this.resetLogsRepo.save(
      this.resetLogsRepo.create({
        studentId: student.id,
        deviceModel: student.deviceModel ?? 'غير معروف',
        byAdmin: 'الإدارة',
      }),
    )
    await this.logActivity(ActionType.DEVICE_RESET, student, {
      details: student.deviceModel ? `الجهاز ${student.deviceModel}` : undefined,
    })
    return { ok: true, resetsUsed: student.resetsUsed }
  }

  async cancelSubscription(studentId: string, subscriptionId: string) {
    const student = await this.mustFind(studentId)
    const sub = await this.subscriptionsRepo.findOne({
      where: { id: subscriptionId, studentId },
    })
    if (!sub) throw new NotFoundException('الاشتراك غير موجود')
    sub.status = SubscriptionStatus.CANCELLED
    await this.subscriptionsRepo.save(sub)
    await this.logActivity(ActionType.CANCEL_SUBSCRIPTION, student, {
      courseNameSnapshot: sub.courseName,
    })
    return { ok: true }
  }

  async openCourse(studentId: string, dto: OpenCourseDto) {
    const student = await this.mustFind(studentId)
    const sub = await this.subscriptionsRepo.save(
      this.subscriptionsRepo.create({
        studentId: student.id,
        courseName: dto.courseName,
        collegeName: dto.collegeName ?? '—',
        price: String(dto.price ?? 0),
        status: SubscriptionStatus.ACTIVE,
      }),
    )
    await this.logActivity(ActionType.OPEN_COURSE, student, {
      courseNameSnapshot: dto.courseName,
    })
    return { ok: true, subscriptionId: sub.id }
  }

  private async mustFind(id: string): Promise<Student> {
    const student = await this.studentsRepo.findOne({ where: { id } })
    if (!student) throw new NotFoundException('الطالب غير موجود')
    return student
  }

  private async logActivity(
    actionType: ActionType,
    student: Student,
    extra: { details?: string; courseNameSnapshot?: string },
  ) {
    await this.activityRepo.save(
      this.activityRepo.create({
        actionType,
        studentId: student.id,
        studentNameSnapshot: student.name,
        adminName: 'الإدارة',
        ...extra,
      }),
    )
  }
}

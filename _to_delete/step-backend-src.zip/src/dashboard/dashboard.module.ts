import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { Student } from '../database/entities/student.entity'
import { Subscription } from '../database/entities/subscription.entity'
import { ActivityLog } from '../database/entities/activity-log.entity'
import { DashboardController } from './dashboard.controller'
import { DashboardService } from './dashboard.service'

@Module({
  imports: [TypeOrmModule.forFeature([Student, Subscription, ActivityLog])],
  controllers: [DashboardController],
  providers: [DashboardService],
})
export class DashboardModule {}

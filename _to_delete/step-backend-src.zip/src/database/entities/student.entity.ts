import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { ResetLog } from './reset-log.entity'
import { Subscription } from './subscription.entity'

export enum StudentStatus {
  ACTIVE = 'ACTIVE',
  BANNED = 'BANNED',
}

/**
 * كيان الطالب — يقابل الحقول الديناميكية في StudentRow / STUDENT_DETAIL /
 * STUDENT_DRAWER (src/data/students.ts في ريبو الداش بورد).
 * النصوص العربية الجاهزة للعرض (تسميات الأعمدة، عناوين الأقسام...) بتفضل في
 * الفرونت زي ما هي — هنا بس القيم الديناميكية الحقيقية.
 */
@Entity('students')
export class Student {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column()
  name: string

  @Column({ unique: true })
  email: string

  @Column()
  phone: string

  @Column({ type: 'enum', enum: StudentStatus, default: StudentStatus.ACTIVE })
  status: StudentStatus

  @Column({ nullable: true })
  deviceModel: string | null

  @Column({ nullable: true })
  deviceIdentifier: string | null

  /** عدد مرات الريست المستخدمة — أقصى حد 3 (قرار مبسّط، شوف README) */
  @Column({ default: 0 })
  resetsUsed: number

  @Column({ type: 'timestamptz', nullable: true })
  lastResetAt: Date | null

  @CreateDateColumn({ type: 'timestamptz' })
  registeredAt: Date

  @OneToMany(() => Subscription, (s) => s.student)
  subscriptions: Subscription[]

  @OneToMany(() => ResetLog, (r) => r.student)
  resetLogs: ResetLog[]
}
